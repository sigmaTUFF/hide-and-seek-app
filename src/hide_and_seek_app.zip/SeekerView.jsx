export default function SeekerView() {
  return (
    <div className="text-center p-4">
      <h1 className="text-xl font-bold">Seeker Ansicht</h1>
      <p>Hier kannst du später dein Seeker-Feature implementieren.</p>
    </div>
  );
}
